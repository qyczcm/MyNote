#ifndef SORT_H_
#define SORT_H_

void bubbleSort(int *array, int len);

void selectSort(int *array, int len);

#endif
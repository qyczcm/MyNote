#!/bin/bash

make server